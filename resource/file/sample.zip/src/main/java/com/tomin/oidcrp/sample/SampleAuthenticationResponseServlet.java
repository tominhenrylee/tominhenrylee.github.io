package com.tomin.oidcrp.sample;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tomin.oidcrp.dao.MemberDao;
import com.tomin.oidcrp.entity.Member;
import com.tomin.oidcrp.userinfo.UserInformation;
import com.tomin.oidcrp.userinfo.UserInformationBuilder;

/**
 * Servlet implementation class CdiServlet
 */
@WebServlet("/callback")
public class SampleAuthenticationResponseServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Inject
	private UserInformationBuilder userInformationBuilder;

	@Inject
	private MemberDao memberDao;
	
	@Inject
	private SampleSessionMember sampleSessionMember;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setCharacterEncoding("UTF-8");

		// initial setup
		PrintWriter writer = null;
		try {
			writer = response.getWriter();
		} catch (IOException e) {
			this.msgErrorOccuredWhile("getting response writer: " + e.getMessage());
		}

		// get userinfo from TominOP
		UserInformation userInformation = null;
		try {
			userInformation = userInformationBuilder.buildByAuthenticationResponse(request);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e.toString());
		}
		
		// set member id
		sampleSessionMember.setMemberId(userInformation.getUserInfo().getSubject().getValue());
		
		// persist member
		Member member = memberDao.getMember(userInformation.getUserInfo().getSubject().getValue());
		if (member == null) {

			member = new Member();
			member.setMemberId(userInformation.getUserInfo().getSubject().getValue());
			member.setRefreshToken(userInformation.getRefreshToken().getValue());
			member.setLoginDateTime(new Date());
			memberDao.createMember(member);
			
			writer.println("Hi " + userInformation.getUserInfo().getNickname()+"("+member.getMemberId() + "), this is your first time using our service! ");

		} else {
			
			member.setLoginDateTime(new Date());
			memberDao.updateMember(member);

			writer.println("Hi " + userInformation.getUserInfo().getNickname()+"("+member.getMemberId() + "), welcome back! ") ;
			
		}

		request.getRequestDispatcher("/index.xhtml").forward(request, response);

	}

	private void msgErrorOccuredWhile(String msg) throws ServletException {
		throw new ServletException("error occured while " + msg);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
