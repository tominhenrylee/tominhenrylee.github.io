package com.tomin.oidcrp.dao;

import javax.ejb.Stateful;
import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.tomin.oidcrp.entity.Member;

@Stateful
@RequestScoped
public class MemberDaoBean implements MemberDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void createMember(Member member) {
		entityManager.persist(member);

	}

	@Override
	public Member getMember(String memberId) {
		Member member = entityManager.find(Member.class, memberId);
		return member;
	}

	@Override
	public void updateMember(Member member) {
		entityManager.merge(member);
		
	}

	@Override
	public void deleteMember(Member member) {
		entityManager.remove(member);
		
	}

}
