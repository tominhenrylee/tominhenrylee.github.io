package com.tomin.oidcrp.sample;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.nimbusds.openid.connect.sdk.claims.UserInfo;
import com.tomin.oidcrp.dao.MemberDao;
import com.tomin.oidcrp.entity.Member;
import com.tomin.oidcrp.exception.AuthenticationResponseInternalException;
import com.tomin.oidcrp.exception.AuthenticationResponseParseException;
import com.tomin.oidcrp.exception.IDTokenSignatureVerificationException;
import com.tomin.oidcrp.exception.InvalidTokenException;
import com.tomin.oidcrp.exception.RedirectUriSyntaxException;
import com.tomin.oidcrp.exception.SessionNotExistException;
import com.tomin.oidcrp.exception.TokenEndpointSyntaxException;
import com.tomin.oidcrp.exception.TokenResponseParseException;
import com.tomin.oidcrp.exception.UserInfoEndpointSyntaxException;
import com.tomin.oidcrp.userinfo.UserInformation;
import com.tomin.oidcrp.userinfo.UserInformationBuilder;

@Named
@RequestScoped
public class SampleMemberInfoDetail {

	@Inject
	private SampleSessionMember sampleSessionMember;
	
	@Inject
	private MemberDao memberDao;
	
	@Inject 
	private UserInformationBuilder userInformationBuilder;
	
	private String Name;
	private String Nickname;
	private String Email;
	
	@PostConstruct
	private void init() {
		
		String refreshToken = getRefreshToken();
		
		UserInformation userInformation = getUserInformation(refreshToken);
		
		
		if (userInformation.getUserInfo()!=null) {
			UserInfo userInfo = userInformation.getUserInfo();
			this.Name = userInfo.getName();
			this.Nickname = userInfo.getNickname();
			this.Email = userInfo.getEmail().toString();
		}
	}
	
	private String getRefreshToken() {
		Member member = memberDao.getMember(sampleSessionMember.getMemberId());
		
		return member.getRefreshToken();
	}
	
	private UserInformation getUserInformation(String refreshToken) {
		
		UserInformation userInformation=null;
		try {
			userInformation = userInformationBuilder.buildByRefreshToken(refreshToken);
		} catch (TokenEndpointSyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RedirectUriSyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AuthenticationResponseInternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AuthenticationResponseParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UserInfoEndpointSyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TokenResponseParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SessionNotExistException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IDTokenSignatureVerificationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidTokenException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return userInformation;
	}

	public String getName() {
		return Name;
	}

	public String getNickname() {
		return Nickname;
	}

	public String getEmail() {
		return Email;
	}
	
}
