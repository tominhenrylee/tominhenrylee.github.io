package com.tomin.oidcrp.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "RP_SAMPLE_MEMBERS")
public class Member {

	@Id
	@Column(name = "MEMBER_ID")
	private String memberId;
	
	@Column(name = "REFRESH_TOKEN")
	private String refreshToken;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LOGIN_DATETIME")
	private Date loginDateTime;

	public String getMemberId() {
		return memberId;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public Date getLoginDateTime() {
		return loginDateTime;
	}

	public void setLoginDateTime(Date loginDateTime) {
		this.loginDateTime = loginDateTime;
	}
	
	
}
