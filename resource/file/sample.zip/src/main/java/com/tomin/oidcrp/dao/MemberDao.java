package com.tomin.oidcrp.dao;

import javax.ejb.Local;

import com.tomin.oidcrp.entity.Member;

@Local
public interface MemberDao {
	public void createMember(Member member);
	public void updateMember(Member member);
	public void deleteMember(Member member);
    public Member getMember(String memberId);
}
