package com.tomin.oidcrp.sample;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.tomin.oidcrp.authentication.AuthenticationRequest;


@Named("sampleAuthReq")
@RequestScoped
public class SampleAuthenticationRequestBacking {
	
	@Inject
	private AuthenticationRequest authReq;
	
	private String uriString;
	
	SampleAuthenticationRequestBacking(){
	}
	
	@PostConstruct	
	private void init() {
		this.uriString = authReq.getUriString();
	}
	
	public String getUriString() {
		
		return uriString;
	}
}
