package com.tomin.oidcrp.sample;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named
@SessionScoped
public class SampleSessionMember implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String memberId;

	public String getMemberId() {
		return memberId;
	}

	void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	
	void invalidateMemberId() {
		this.memberId = null;
	}
	
	public boolean isLoggedIn() {
		return this.memberId!=null;
	}
	
	public void logout() {
		this.memberId = null;
	}
}
